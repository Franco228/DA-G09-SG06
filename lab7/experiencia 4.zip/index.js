
import './index2.css';
import './index.css';
import { useState, createContext, useContext } from "react";
import ReactDOM from "react-dom/client";

const UserContext = createContext();

function Component1() {
 const [codigo, setcodigo] = useState("");

 return (
   <UserContext.Provider value={codigo}>
     <div className='Contenido'>
       <h4>Mostrar codigos de los estudiantes</h4>
       <h4>Haga click en un estudiante para saber su codigo: </h4>
       <div className='Estudiante'>
         <button type="button" onClick={() => setcodigo("2022205821")}>
           Aaron Farid Roig Valdivia
         </button>
         <button type="button" onClick={() => setcodigo("2022206871")}>
           Franco Alessandro Valenzuela Chavez
         </button>
         <button type="button" onClick={() => setcodigo("2020000000")}>
           XXXXX XXXXX XXXXX XXXXX
         </button>
       </div>
     </div>
     <Component2 />
   </UserContext.Provider>
 );
}

function Component2() {
 return (
   <>
     <h2> Datos:</h2>
     <Component3 />
   </>
 );
}

function Component3() {
 const codigo = useContext(UserContext);
 return (
   <>
     <h3> Codigo: {codigo}</h3>
   </>
 );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Component1 />);
